package co.edu.usco.backendparcial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendParcialApplication {

    public static void main(String[] args) {
        SpringApplication.run(BackendParcialApplication.class, args);
    }

}
