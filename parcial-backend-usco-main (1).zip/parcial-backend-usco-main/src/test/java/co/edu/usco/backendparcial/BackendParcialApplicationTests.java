package co.edu.usco.backendparcial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendParcialApplicationTests {

    @Test
    void contextLoads() {
    }

}
